<?php

// Durée maximale d'inactivité : 30 secondes pour le test
$delai_inactivite = 30;

// Vérifier si l'utilisateur est connecté
if (isset($_SESSION['user_id'])) {

    // Récupérer la dernière activité
    $derniere_activite = $_SESSION['last_activity'] ?? time();

    // Vérifier si le délai est dépassé
    if (time() - $derniere_activite >= $delai_inactivite) {

        // Supprimer les informations de connexion
        unset(
            $_SESSION['user_id'],
            $_SESSION['username'],
            $_SESSION['nom'],
            $_SESSION['prenom'],
            $_SESSION['last_activity']
        );

        // Renouveler l'identifiant de session
        session_regenerate_id(true);

        // Préparer la notification
        $_SESSION['flash'] =
            "Votre session a expiré après 30 secondes d'inactivité.";

        $_SESSION['flash_type'] = 'error';

        // Retourner à la page Login
        header('Location: index.php#login');
        exit();
    }

    // Mettre à jour la dernière activité
    $_SESSION['last_activity'] = time();
}
