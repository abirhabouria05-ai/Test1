<?php
session_start();

header('Content-Type: application/json');

// Vérifier si l'utilisateur est connecté
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    exit();
}

// Durée maximale d'inactivité : 30 secondes pour le test
$delai_inactivite = 30;

// Récupérer la dernière activité
$derniere_activite = $_SESSION['last_activity'] ?? time();

// Vérifier l'expiration
if (time() - $derniere_activite >= $delai_inactivite) {

    // Supprimer les informations de connexion
    unset(
        $_SESSION['user_id'],
        $_SESSION['username'],
        $_SESSION['nom'],
        $_SESSION['prenom'],
        $_SESSION['last_activity']
    );

    // Renouveler l'identifiant de session
    session_regenerate_id(true);

    // Préparer la notification
    $_SESSION['flash'] =
        "Votre session a expiré après 30 secondes d'inactivité.";

    $_SESSION['flash_type'] = 'error';

    http_response_code(401);
    exit();
}

// Mettre à jour la dernière activité
$_SESSION['last_activity'] = time();

echo json_encode(['success' => true]);
