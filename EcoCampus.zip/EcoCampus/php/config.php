<?php
define('GROQ_API_KEY', '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');
define('GROQ_MODEL', 'openai/gpt-oss-20b');

define('GMAIL_USERNAME','malekchuigui@gmail.com');
define('GMAIL_PASSWORD','kscv bghv kdmo eqte');
